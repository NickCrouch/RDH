num.polygons <- function(x, return.sizes=FALSE){
    
    if(!return.sizes){
        #1) Create master list of all polygon files within a shapefile
        
        #How many lists of polygons are there within the shpfile
        num.polygon.lists <- length(x@polygons)
        
        
        #Get all polygon files
        master <- vector(mode="list")
        for(i in 1:num.polygon.lists){
            m <- x@polygons[[i]]@Polygons
            
            master[[i]] <- m
        }
        
        #Combine polygon files into a single list
        len <- length(master)
        
        if(len > 1) {
            
            root <- master[[1]]
            for(i in 2:length(master)){
                root <- c(master[[i]], root)}
            
        } else {root <- master[[1]]}
        
        #Rename
        polygon.files <- root
        
        #2) Count number of polygon files that are not holes
        
        #Create a matrix for the total number of polygon slots that are going to be counted
        res <- matrix(NA,ncol=1 , nrow=length(polygon.files))
        
        #Loop through polygons returning whether slot "hole" is TRUE/FALSE
        for(i in 1:length(polygon.files)){
            
            r <- isTRUE(polygon.files[[i]]@hole)
            
            res[[i,1]] <- r
        }
        
        #Count number times "FALSE" appears - means polygon is not a hole
        p.count <- table(res)["FALSE"]
        p.count <- as.numeric(p.count)
         
       name <- as.character(x@data$SCINAME)

       names(p.count) <- name[1]

        return(p.count)
        
    }
    
    
    if(return.sizes){
        
        #1) Create master list of all polygon files within a shapefile
        
        #How many lists of polygons are there within the shpfile
        num.polygon.lists <- length(x@polygons)
        
        
        #Get all polygon files
        master <- vector(mode="list")
        for(i in 1:num.polygon.lists){
            m <- x@polygons[[i]]@Polygons
            
            master[[i]] <- m
        }
        
        #Combine polygon files into a single list
        len <- length(master)
        
        if(len > 1) {
            
            root <- master[[1]]
            for(i in 2:length(master)){
                root <- c(master[[i]], root)}
            
        } else {root <- master[[1]]}
        
        #Rename
        polygon.files <- root
        
        #2) Count number of polygon files that are not holes
        
        #Create a matrix for the total number of polygon slots that are going to be counted
        res <- matrix(NA,ncol=1 , nrow=length(polygon.files))
        
        #Loop through polygons returning whether slot "hole" is TRUE/FALSE
        for(i in 1:length(polygon.files)){
            
            r <- isTRUE(polygon.files[[i]]@hole)
            
            res[[i,1]] <- r
        }
        
        #Count number times "FALSE" appears - means polygon is not a hole
        p.count <- table(res)["FALSE"]
        p.count <- as.numeric(p.count)
        
        
        
        #each item of a list is the sizes of the polygons in that shapefile
        #output.vector <- vector(mode="list",length=length(x))
        
        storage <- matrix(NA, ncol=1, nrow=1)
        storage <- as.data.frame(storage)
        colnames(storage) <- "fragment sizes"
        
        for(i in 1:length(polygon.files)){
            s.t <- polygon.files[[i]]
            crds <- coordinates(s.t)
            ply <- Polygons(list(Polygon(crds)),"crds")
            s.t1 <- SpatialPolygons(list(ply))
            t.a <- gArea(s.t1)
            
            storage[i,1] <- t.a
            
        }
        
        output <- vector(mode="list",length=2)
        
        
        
        return(storage)
        
    }
}
