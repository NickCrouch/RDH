rangeOverlaps.phyloDist <- function(shapefiles, phylo, weight.relatives=TRUE){
    
    require(sp)
    require(ape)
    require(maptools)
    require(rgeos)
    
    phy <- phylo
    shp <- shapefiles
    
    phy.names <- phy$tip.label
    
    ######
    # Check names are in phylogeny
    ######
    
    if( is.null(phylo) == FALSE){
        
        names <- vector()
        
        for(i in 1:length(shp)){
            
            n <- as.character(shp[[i]]@data$SCINAME[[1]])
            
            n <- gsub(" ","_",n)
            
            check <- n %in% phy$tip.label
            
            if(check == FALSE){
                
                names <- c(names, n)
                
            }
            
        }
        
        bad.spp <- length(names)
        
        if(bad.spp > 0) warning(names," ","not in phylogeny")
        
    }
    
    ######
    # Create storage
    #######
    
    if( is.null(phylo) == TRUE){
        storage <- matrix(NA, ncol=2, nrow=1)
        storage <- as.data.frame(storage)
        colnames(storage) <- c("ID","number_of_overlaps") } else{
            
            
            storage <- matrix(NA, ncol=3, nrow=1)
            storage <- as.data.frame(storage)
            colnames(storage) <- c("ID","total.phylo.distance","number.of.overlaps")
        }
    
    ###
    
    for(i in 1:length(shp)){
        
        total.distance <- 0
        count <- vector()
        
        #Load first shapefile
        s <- shp[[i]]
        print(i)
        
        #Get name for that file
        name.1 <- s@data$SCINAME[1]
        name.n <- as.character(name.1)
        name.t <- gsub(" ","_",name.n)
        
        
        storage[i,1] <- name.t
        
        #Make sure all polygons treated as one
        s <- gUnionCascaded(s)
        
        
        # just counts
        if( is.null(phylo) == TRUE){
            
            for (k in 1:length(shp)){
                
                if(k != i){
                    s2 <- shp[[k]] 
                    gUnionCascaded(s2)
                    
                    #Get name of second shapefile
                    name.2 <- s2@data$SCINAME[1]
                    name.n2 <- as.character(name.2)
                    name.t2 <- gsub(" ","_",name.n2)
                    
                    
                    # polygons overlap?
                    v <- over(s, s2)
                    
                    v <- as.numeric(v)
                    
                    if((is.na(v)) ==FALSE) {
                        
                        add <- 1 } else{add <- 0}
                    
                    count <- c(count, add)
                    
                    
                }
            }
            
            l <- sum(count, na.rm=T)
            storage[i,2] <- l
            
            
            
            
        } else {
            
            for (k in 1:length(shp)){
                
                if(k != i){
                    s2 <- shp[[k]] 
                    gUnionCascaded(s2)
                    
                    #Get name of second shapefile
                    name.2 <- s2@data$SCINAME[1]
                    name.n2 <- as.character(name.2)
                    name.t2 <- gsub(" ","_",name.n2)
                    
                    
                    
                    # polygons overlap?
                    v <- over(s, s2)
                    
                    v <- as.numeric(v)
                    
                    if((is.na(v)) ==FALSE) {
                        
                        add <- 1 } else{add <- 0}
                    
                    count <- c(count, add)
                    
                    
                    #Patristic distance on tree
                    if(add == 1){
                        dist <- cophenetic(phy)[name.t,name.t2]
                        if(dist > 0){
                            if(weight.relatives==TRUE){
                                dist <- 1/dist}
                        }
                        total.distance <- c(total.distance, dist)
                        
                        
                    }
                    total.distance <- sum(total.distance)
                    storage[i,2] <- total.distance
                    l <- sum(count, na.rm=T)
                    storage[i,3] <- l
                    
                    storage[i,1] <- name.t
                    
                }
                
            }
        }
    }
    return(storage)
}
