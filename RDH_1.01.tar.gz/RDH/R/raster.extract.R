raster.extract <- function(x, raster.layer, stat.test="mean", na.val=NULL){

if( is.null(na.val == FALSE)){
fun <- function(y) { y[y== na.val] <- NA; return(y) }
}

temp <- gUnionCascaded(x)

extract <- extract(raster.layer,temp)

if( is.null(na.val == FALSE)){
extract <- lapply(extract, FUN=fun)
}

mean <- lapply(extract, FUN=stat.test, na.rm=T)

mean <- mean[[1]]

return(mean)

}


