seasonal.distribution.ranges <- function(x) {

name <- as.character(x@data$SCINAME[1])

name <- gsub(" ","_",name)

exp.data <- x@data[1,1:3]
rownames(exp.data) <- "1"

range.names <- c("resident","breeding","non-breeding","passage","unknown")

dists <- unique(as.numeric(x@data$SEASONAL))

returned.files <- vector(mode="list",length=length(dists))

for(i in 1:length(dists)){

val <- dists[[i]]

sub.shp <- x[x@data$SEASONAL == val,]

sub.shp <- gUnionCascaded(sub.shp)

spdf <- SpatialPolygonsDataFrame(sub.shp, exp.data)

spdf@data$SCINAME <- paste(name,"_",range.names[val])

returned.files[[i]] <- spdf

}

return(returned.files)
} 
