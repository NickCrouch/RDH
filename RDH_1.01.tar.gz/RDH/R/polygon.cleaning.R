polygon.cleaning <- function(x, resolution=0.5){

require(rgeos)
require(raster)

r.s <- raster(extent(x))
res(r.s) <- resolution
rast <- rasterize(x, r.s)
new.s <- rasterToPolygons(rast,n=4,dissolve=T)

new.s <- gUnionCascaded(new.s)

exp.data <- x@data

exp.data.trim <- exp.data[1,1:3]

rownames(exp.data.trim) <- "1"
spdf <- SpatialPolygonsDataFrame(new.s, exp.data.trim)

return(spdf)

}




