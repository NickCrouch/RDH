nameFix <- function(x, as.list=FALSE){
    if (!as.list){
    name.n <- gsub('([A-z]+)_([A-z]+)_.*', '\\1 \\2', x)
    name.f <- gsub(" ", "_", name.n)
    return(name.f)
    } else {
	output <- vector(mode ="list",length=length(x))  
	for(i in 1:length(x)){
	nam <- x[[i]]
	name.n <- gsub('([A-z]+)_([A-z]+)_.*', '\\1 \\2', nam)
	name.f <- gsub(" ", "_", name.n)
        output[[i]] <- name.f
	}
	return(output)
    }
}
