

migration.distance <- function(shp){

# Check to see whether breeding and non-breeding ranges present in shapefile

if((2 %in% shp$SEASONAL) == FALSE){
stop("Shapefile does not contain breeding range")
}

if((3 %in% shp$SEASONAL) == FALSE){
stop("Shapefile does not contain breeding range")
}


# Get areas of the breeding and non-breeding ranges


breeding <- shp[shp$SEASONAL == 2,]

breeding <- gUnionCascaded(breeding)

breeding.area <- gArea(breeding)

##

wintering <- shp[shp$SEASONAL == 3,]

wintering <- gUnionCascaded(wintering)

wintering.area <- gArea(wintering)


# get coordinates using coordinates() function in {sp}

breeding.coord <- coordinates(breeding)

wintering.coord <- coordinates(wintering)


# get distance between coordinates accounting for the curve of the earth


dist <- rbind(breeding.coord, wintering.coord)


d <- earth.dist(dist)

d <- as.numeric(d)


results <- as.data.frame(matrix(NA, ncol=8, nrow=1))
colnames(results) <- c("Species","Breeding Range Size","Wintering Range Size","Breeding Range Centroid X","Breeding Range Centroid Y","Wintering Range Centroid X","Wintering Range Centroid Y","Migration Distance")

results[1,1] <- as.character(shp$SCINAME[1])
results[1,2] <- breeding.area
results[1,3] <- wintering.area
results[1,4] <- breeding.coord[1,1]
results[1,5] <- breeding.coord[1,2]
results[1,6] <- wintering.coord[1,1]
results[1,7] <- wintering.coord[1,2]
results[1,8] <- d

return(results)

}

