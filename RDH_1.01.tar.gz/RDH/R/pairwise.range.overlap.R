pairwise.range.overlap <- function(x){
    
    shp <- x
    
    l <- length(shp)
    
    storage <- as.data.frame(matrix(NA, ncol=l, nrow=l))
    
    row.names <- vector()
    
    for(i in 1:length(shp)){
        
        s <- shp[[i]]
        
        name <- as.character(s@data$SCINAME[1])
        row.names[i] <- name
        
        s <- gUnionCascaded(s)
        
        base.area <- gArea(s)
        
        for(k in 1:length(shp)){
            
            if(i != k){
                
                s2 <- shp[[k]]
                
                s2 <- gUnionCascaded(s2)
                
                overlap <- gIntersection(s, s2)
                
                if( is.null(overlap) == TRUE){
                    
                    storage[i,k] <- 0 } else {
                        
                        
                        overlap.area <- gArea(overlap)
                        
                        percentage <- overlap.area / base.area
                        
                        storage[i,k] <- percentage }
                
            }
            
            
        }
        
         p <- (i/l)*100
         p <- round(p, 2)
         print(paste(p,"% done"))
    }
    
    rownames(storage) <- row.names
    colnames(storage) <- row.names
    return(storage)
}

