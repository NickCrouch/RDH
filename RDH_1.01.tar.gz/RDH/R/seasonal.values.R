seasonal.values <- function(x){

seasons <- as.numeric(x@data$SEASONAL)

seasons <- unique(seasons)


returned.seasons <- vector()


if((1 %in% seasons) == TRUE){

returned.seasons <- c(returned.seasons, "Resident")

}

if((2 %in% seasons) == TRUE){

returned.seasons <- c(returned.seasons, "Breeding Season")

}

if((3 %in% seasons) == TRUE){

returned.seasons <- c(returned.seasons, "Non-breeding Season")

}

if((4 %in% seasons) == TRUE){

returned.seasons <- c(returned.seasons, "Passage")

}

if((5 %in% seasons) == TRUE){

returned.seasons <- c(returned.seasons, "Seasonal Occurance Uncertain")

}

return(returned.seasons)

}
